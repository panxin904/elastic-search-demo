#!/usr/bin/env bash
# Build all VitePress sites and create one deployable static archive.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
RELEASE_DIR="$PROJECT_ROOT/release"
STAGE_DIR="$RELEASE_DIR/sites-hub"
ARCHIVE="$RELEASE_DIR/sites-hub-static.tar.gz"

if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
  echo "node and npm are required to build the sites." >&2
  exit 1
fi

rm -rf "$STAGE_DIR"
mkdir -p "$STAGE_DIR"
cp -R "$SCRIPT_DIR/www" "$STAGE_DIR/www"

for project in es-html mysql-html redis-html springcloud-html python-html kafka-html java-web-manual tools-html frontend-html linux-html cloud-native-html ai-html java-language-html bigdata-html architecture-html network-html video-html filesystem-html system-design-html postgresql-html observability-html security-html devops-html rust-html go-html clickhouse-html design-pattern-html; do
  project_dir="$PROJECT_ROOT/$project"
  case "$project" in
    es-html) target_name="es" ;;
    mysql-html) target_name="mysql" ;;
    redis-html) target_name="redis" ;;
    springcloud-html) target_name="cloud" ;;
    python-html) target_name="python" ;;
    kafka-html) target_name="kafka" ;;
    java-web-manual) target_name="java" ;;
    tools-html) target_name="tools" ;;
    frontend-html) target_name="frontend" ;;
    linux-html) target_name="linux" ;;
    cloud-native-html) target_name="cloud-native" ;;
    ai-html) target_name="ai" ;;
    java-language-html) target_name="java-language" ;;
    bigdata-html) target_name="bigdata" ;;
    architecture-html) target_name="architecture" ;;
    network-html) target_name="network" ;;
    video-html) target_name="video" ;;
    filesystem-html) target_name="filesystem" ;;
    system-design-html) target_name="system-design" ;;
    postgresql-html) target_name="postgresql" ;;
    observability-html) target_name="observability" ;;
    security-html) target_name="security" ;;
    devops-html) target_name="devops" ;;
    rust-html) target_name="rust" ;;
    go-html) target_name="go" ;;
    clickhouse-html) target_name="clickhouse" ;;
    design-pattern-html) target_name="design-pattern" ;;
  esac
  target_dir="$STAGE_DIR/$target_name"

  echo "==> Building $project"
  (
    cd "$project_dir"
    # package-lock.json is committed for every site; npm ci keeps builds reproducible.
    npm ci
    npm run docs:build
  )

  # Postbuild: copy public/ contents to dist/ (VitePress 1.6.4 doesn't do this on macOS).
  # This is a known bug — affects favicon.ico / apple-touch-icon.png etc.
  if [ -d "$project_dir/.vitepress/public" ]; then
    cp -R "$project_dir/.vitepress/public/." "$project_dir/.vitepress/dist/" 2>/dev/null || true
  fi

  mkdir -p "$target_dir"
  cp -R "$project_dir/.vitepress/dist/." "$target_dir/"
done

cp "$SCRIPT_DIR/deploy-vps.sh" "$STAGE_DIR/deploy-vps.sh"
chmod +x "$STAGE_DIR/deploy-vps.sh"

rm -f "$ARCHIVE"
tar -C "$RELEASE_DIR" -czf "$ARCHIVE" sites-hub

echo "Release archive created: $ARCHIVE"
