#!/bin/bash
# 一键启动所有静态网站
# 用法: ./start-all.sh

set -e

HUB_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECTS=("es-html" "mysql-html" "springcloud-html" "redis-html" "python-html" "kafka-html" "java-web-manual" "tools-html" "frontend-html" "linux-html" "cloud-native-html" "ai-html" "java-language-html" "bigdata-html" "network-html" "video-html" "filesystem-html")

echo "========================================="
echo "  十二个静态网站 - 一键启动"
echo "========================================="

# 1. 构建三个网站
for proj in "${PROJECTS[@]}"; do
  proj_dir="$HUB_DIR/../$proj"
  if [ -d "$proj_dir" ]; then
    echo ""
    echo "📦 构建 $proj..."
    cd "$proj_dir"
    if [ ! -d node_modules ]; then
      echo "   安装依赖..."
      npm install --silent
    fi
    npm run docs:build 2>&1 | tail -3
  fi
done

# 2. 启动 nginx
echo ""
echo "========================================="
echo "  🚀 启动 Nginx (单域名访问三个网站)"
echo "========================================="

# 检查 nginx 是否安装
if ! command -v nginx &> /dev/null; then
  echo "❌ 未检测到 nginx，请先安装:"
  echo "   macOS:  brew install nginx"
  echo "   Ubuntu: sudo apt install nginx"
  echo "   CentOS: sudo yum install nginx"
  exit 1
fi

# 启动 nginx
NGINX_CMD="nginx -c $HUB_DIR/conf/nginx.conf -p $HUB_DIR"
if pgrep -f "nginx.*sites-hub" &> /dev/null; then
  echo "nginx 已在运行，重新加载配置..."
  nginx -c $HUB_DIR/conf/nginx.conf -p $HUB_DIR -s reload
else
  echo "启动 nginx..."
  $NGINX_CMD
fi

echo ""
echo "✅ 启动成功！"
echo ""
echo "🌐 访问地址："
echo "   首页导航:    http://localhost/"
echo "   ES 网站:    http://localhost/es/"
echo "   MySQL 网站:  http://localhost/mysql/"
echo "   Redis:        http://localhost/redis/"
echo "   Spring Cloud: http://localhost/cloud/"
echo "   Python:       http://localhost/python/"
echo "   Kafka:        http://localhost/kafka/"
echo "   Java Web:     http://localhost/java/"
echo "   常用工具:     http://localhost/tools/"
echo "   前端 + Node:   http://localhost/frontend/"
echo "   Linux 服务器:   http://localhost/linux/"
echo "   云原生:         http://localhost/cloud-native/"
echo "   AI 工程:       http://localhost/ai/"
echo "   大数据:        http://localhost/bigdata/"
echo "   计算机网络:     http://localhost/network/"
echo "   视频处理:       http://localhost/video/"
echo "   文件系统:       http://localhost/filesystem/"
echo ""
echo "📁 停止: pkill -f 'nginx.*sites-hub'"
