#!/bin/bash
# 三个静态网站一站式启动
# 优先使用 Nginx，没有则用 Python 备用方案
# 用法: ./start.sh [stop|build|start|status]

set -e

HUB_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECTS=("es-html" "mysql-html" "springcloud-html" "redis-html" "python-html" "kafka-html" "java-web-manual" "tools-html" "frontend-html" "linux-html" "cloud-native-html" "ai-html" "java-language-html" "bigdata-html" "network-html" "video-html" "filesystem-html")
PY_HUB="$HUB_DIR/start-hub.py"
NGINX_CONF="$HUB_DIR/conf/nginx.conf"
NGINX_PREFIX="$HUB_DIR"

cmd="${1:-start}"

build_all() {
  echo "=========================================="
  echo "  📦 构建三个网站"
  echo "=========================================="
  for proj in "${PROJECTS[@]}"; do
    proj_dir="$HUB_DIR/../$proj"
    if [ ! -d "$proj_dir" ]; then
      echo "❌ 目录不存在: $proj_dir"
      exit 1
    fi
    if [ ! -d "$proj_dir/.vitepress/dist" ] || [ "${REBUILD:-0}" = "1" ]; then
      echo ""
      echo "🔨 构建 $proj..."
      cd "$proj_dir"
      if [ ! -d node_modules ]; then
        echo "   安装依赖..."
        npm install --silent
      fi
      npm run docs:build 2>&1 | tail -2
    else
      echo "✅ $proj 已构建（跳过）"
    fi
  done
}

start_nginx() {
  if ! command -v nginx &> /dev/null; then
    return 1
  fi
  if pgrep -f "nginx.*sites-hub" &> /dev/null; then
    nginx -c "$NGINX_CONF" -p "$NGINX_PREFIX" -s reload
    echo "✅ nginx 已重新加载"
  else
    nginx -c "$NGINX_CONF" -p "$NGINX_PREFIX"
    echo "✅ nginx 已启动"
  fi
  return 0
}

start_python() {
  if lsof -i :8080 &> /dev/null; then
    echo "⚠️  8080 端口已被占用，请先停掉"
    return 1
  fi
  echo "ℹ️  使用 Python 备用方案（端口 8080）"
  cd "$HUB_DIR"
  nohup python3 "$PY_HUB" > "$HUB_DIR/hub.log" 2>&1 &
  echo $! > "$HUB_DIR/hub.pid"
  sleep 1
  echo "✅ Python 静态服务已启动 (PID: $(cat $HUB_DIR/hub.pid))"
}

case "$cmd" in
  build)
    REBUILD=1 build_all
    echo ""
    echo "✅ 构建完成"
    ;;
  stop)
    echo "停止所有相关服务..."
    if pgrep -f "nginx.*sites-hub" &> /dev/null; then
      nginx -c "$NGINX_CONF" -p "$NGINX_PREFIX" -s quit
      echo "✅ nginx 已停止"
    fi
    if [ -f "$HUB_DIR/hub.pid" ]; then
      kill "$(cat $HUB_DIR/hub.pid)" 2>/dev/null && echo "✅ Python hub 已停止"
      rm -f "$HUB_DIR/hub.pid"
    fi
    ;;
  status)
    echo "=== 状态检查 ==="
    if pgrep -f "nginx.*sites-hub" &> /dev/null; then
      echo "✅ nginx: 运行中"
    else
      echo "⚪ nginx: 未运行"
    fi
    if [ -f "$HUB_DIR/hub.pid" ] && kill -0 "$(cat $HUB_DIR/hub.pid)" 2>/dev/null; then
      echo "✅ Python hub: 运行中 (PID: $(cat $HUB_DIR/hub.pid))"
    else
      echo "⚪ Python hub: 未运行"
    fi
    ;;
  start|*)
    build_all
    echo ""
    echo "=========================================="
    echo "  🚀 启动统一访问入口"
    echo "=========================================="
    if start_nginx; then
      echo ""
      echo "  🌐 访问地址（nginx 80 端口）:"
    else
      start_python
      echo ""
      echo "  🌐 访问地址（Python 8080 端口）:"
    fi
    echo "     首页导航:   http://localhost/"
    echo "     ES 网站:    http://localhost/es/"
    echo "     MySQL:      http://localhost/mysql/"
    echo "     Spring Cloud: http://localhost/cloud/"
    echo "     Python:       http://localhost/python/"
    echo "     Kafka:        http://localhost/kafka/"
    echo "     Java Web:     http://localhost/java/"
    echo "     常用工具:     http://localhost/tools/"
    echo "     前端 + Node:   http://localhost/frontend/"
    echo "     Linux 服务器:   http://localhost/linux/"
    echo "     云原生:         http://localhost/cloud-native/"
    echo "     AI 工程:       http://localhost/ai/"
    echo "     大数据:        http://localhost/bigdata/"
    echo "     计算机网络:     http://localhost/network/"
    echo "     视频处理:       http://localhost/video/"
    echo "     文件系统:       http://localhost/filesystem/"
    echo ""
    echo "  📁 查看日志: tail -f $HUB_DIR/hub.log"
    echo "  🛑 停止:     $0 stop"
    ;;
esac
