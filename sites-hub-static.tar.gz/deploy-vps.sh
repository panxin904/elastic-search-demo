#!/usr/bin/env bash
# Run this script on the VPS after extracting sites-hub-static.tar.gz.
# Usage: sudo ./deploy-vps.sh example.com admin@example.com [basic_auth_username]
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Run this deployment script with sudo or as root." >&2
  exit 1
fi

SERVER_NAME="${1:-}"
CERTBOT_EMAIL="${2:-}"
AUTH_USER="${3:-}"
if [[ -z "$SERVER_NAME" || -z "$CERTBOT_EMAIL" ]]; then
  echo "Usage: sudo $0 example.com admin@example.com [basic_auth_username]" >&2
  exit 1
fi
if ! [[ "$SERVER_NAME" =~ ^[A-Za-z0-9.-]+$ ]] || [[ "$SERVER_NAME" != *.* ]]; then
  echo "Use a valid domain name (for example: docs.example.com), not an IP address." >&2
  exit 1
fi

if [[ -z "$AUTH_USER" ]]; then
  read -r -p "Basic Auth username: " AUTH_USER
fi
if [[ -z "$AUTH_USER" ]]; then
  echo "Basic Auth username cannot be empty." >&2
  exit 1
fi

while true; do
  read -r -s -p "Password for ${AUTH_USER}: " AUTH_PASSWORD
  echo
  read -r -s -p "Confirm password: " AUTH_PASSWORD_CONFIRM
  echo
  if [[ -n "$AUTH_PASSWORD" && "$AUTH_PASSWORD" == "$AUTH_PASSWORD_CONFIRM" ]]; then
    break
  fi
  echo "Passwords are empty or do not match; try again." >&2
done
unset AUTH_PASSWORD_CONFIRM

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WEB_ROOT="/var/www/sites-hub"
RELEASES_DIR="$WEB_ROOT/releases"
RELEASE_ID="$(date +%Y%m%d%H%M%S)"
RELEASE_DIR="$RELEASES_DIR/$RELEASE_ID"
CURRENT_LINK="$WEB_ROOT/current"
ACME_ROOT="/var/www/certbot"
AUTH_FILE="/etc/nginx/.sites-hub.htpasswd"

install_dependencies() {
  if command -v apt-get >/dev/null; then
    apt-get update
    apt-get install -y nginx apache2-utils certbot
  elif command -v dnf >/dev/null; then
    dnf install -y nginx httpd-tools certbot
  elif command -v yum >/dev/null; then
    yum install -y nginx httpd-tools certbot
  else
    echo "Could not find apt-get, dnf, or yum to install dependencies." >&2
    exit 1
  fi
}

configure_path() {
  if [[ -d /etc/nginx/sites-available ]]; then
    CONFIG_PATH="/etc/nginx/sites-available/sites-hub.conf"
    ln -sfn "$CONFIG_PATH" /etc/nginx/sites-enabled/sites-hub.conf
    # This VPS is dedicated to the sites hub; otherwise the distribution's
    # default server can answer IP requests instead of this virtual host.
    rm -f /etc/nginx/sites-enabled/default
  else
    CONFIG_PATH="/etc/nginx/conf.d/sites-hub.conf"
  fi
}

write_http_only_config() {
  cat > "$CONFIG_PATH" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${SERVER_NAME};

    location ^~ /.well-known/acme-challenge/ {
        root ${ACME_ROOT};
        auth_basic off;
        try_files \$uri =404;
    }

    location / {
        return 301 https://\$host\$request_uri;
    }
}
EOF
}

write_https_config() {
  cat > "$CONFIG_PATH" <<EOF
server {
    listen 80;
    listen [::]:80;
    server_name ${SERVER_NAME};

    location ^~ /.well-known/acme-challenge/ {
        root ${ACME_ROOT};
        auth_basic off;
        try_files \$uri =404;
    }

    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name ${SERVER_NAME};
    charset utf-8;

    ssl_certificate /etc/letsencrypt/live/${SERVER_NAME}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${SERVER_NAME}/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;

    add_header Strict-Transport-Security "max-age=31536000" always;
    gzip on;
    gzip_types text/plain text/css application/javascript application/json image/svg+xml;

    auth_basic "Private documentation";
    auth_basic_user_file ${AUTH_FILE};

    location = /es { return 301 /es/; }
    location = /mysql { return 301 /mysql/; }
    location = /redis { return 301 /redis/; }
    location = /cloud { return 301 /cloud/; }
    location = /python { return 301 /python/; }
    location = /kafka { return 301 /kafka/; }
    location = /java { return 301 /java/; }
    location = /tools { return 301 /tools/; }
    location = /frontend { return 301 /frontend/; }
    location = /linux { return 301 /linux/; }
    location = /cloud-native { return 301 /cloud-native/; }
    location = /ai { return 301 /ai/; }
    location = /bigdata { return 301 /bigdata/; }
    location = /network { return 301 /network/; }
    location = /video { return 301 /video/; }
    location = /filesystem { return 301 /filesystem/; }

    location /es/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /mysql/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /redis/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /cloud/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /python/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /kafka/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /java/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /tools/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /frontend/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /linux/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /cloud-native/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /ai/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /bigdata/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /network/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /video/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location /filesystem/ {
        root ${CURRENT_LINK};
        try_files \$uri \$uri.html \$uri/index.html =404;
    }

    location / {
        root ${CURRENT_LINK}/www;
        try_files \$uri \$uri/ =404;
    }
}
EOF
}

install_dependencies
configure_path

mkdir -p "$RELEASE_DIR" "$ACME_ROOT"
cp -R "$SCRIPT_DIR/www" "$RELEASE_DIR/www"
for site in es mysql redis cloud python kafka java tools frontend linux cloud-native ai bigdata network video filesystem; do
  cp -R "$SCRIPT_DIR/$site" "$RELEASE_DIR/$site"
done
ln -sfn "$RELEASE_DIR" "$CURRENT_LINK"

printf '%s\n' "$AUTH_PASSWORD" | htpasswd -c -i "$AUTH_FILE" "$AUTH_USER"
chmod 640 "$AUTH_FILE"
unset AUTH_PASSWORD

# Serve only the ACME challenge on HTTP while requesting the first certificate.
write_http_only_config
nginx -t
if command -v systemctl >/dev/null; then
  systemctl enable --now nginx
  systemctl reload nginx
else
  nginx -s reload || nginx
fi

certbot certonly --webroot -w "$ACME_ROOT" \
  --non-interactive --agree-tos --keep-until-expiring \
  --email "$CERTBOT_EMAIL" -d "$SERVER_NAME"

write_https_config
nginx -t
if command -v systemctl >/dev/null; then
  systemctl reload nginx
  systemctl enable --now certbot.timer 2>/dev/null || true
else
  nginx -s reload
fi

echo "Deployment complete. Visit: https://${SERVER_NAME}/"
