#!/usr/bin/env python3
"""
三个静态网站一站式访问（Python 实现的反向代理）
用法: python3 start-hub.py
访问: http://localhost:8080/

路由:
  /es/       → es-html/dist
  /mysql/    → mysql-html/dist
  /cloud/    → springcloud-html/dist
  /          → 统一导航首页
"""
import http.server
import socketserver
import os
import sys
from pathlib import Path
from urllib.parse import urlparse, unquote

HUB_DIR = Path(__file__).parent.resolve()
PROJECTS = {
    "/es/": HUB_DIR.parent / "es-html" / ".vitepress" / "dist",
    "/mysql/": HUB_DIR.parent / "mysql-html" / ".vitepress" / "dist",
    "/cloud/": HUB_DIR.parent / "springcloud-html" / ".vitepress" / "dist",
    "/redis/": HUB_DIR.parent / "redis-html" / ".vitepress" / "dist",
    "/python/": HUB_DIR.parent / "python-html" / ".vitepress" / "dist",
    "/kafka/": HUB_DIR.parent / "kafka-html" / ".vitepress" / "dist",
    "/java/": HUB_DIR.parent / "java-web-manual" / ".vitepress" / "dist",
    "/tools/": HUB_DIR.parent / "tools-html" / ".vitepress" / "dist",
    "/frontend/": HUB_DIR.parent / "frontend-html" / ".vitepress" / "dist",
    "/linux/": HUB_DIR.parent / "linux-html" / ".vitepress" / "dist",
    "/cloud-native/": HUB_DIR.parent / "cloud-native-html" / ".vitepress" / "dist",
    "/ai/": HUB_DIR.parent / "ai-html" / ".vitepress" / "dist",
    "/bigdata/": HUB_DIR.parent / "bigdata-html" / ".vitepress" / "dist",
    "/network/": HUB_DIR.parent / "network-html" / ".vitepress" / "dist",
    "/video/": HUB_DIR.parent / "video-html" / ".vitepress" / "dist",
    "/filesystem/": HUB_DIR.parent / "filesystem-html" / ".vitepress" / "dist",
}
HUB_INDEX = HUB_DIR / "www" / "index.html"
PORT = 8080

class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        path = unquote(urlparse(self.path).path)

        # 统一首页
        if path in ("/", "/index.html"):
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            with open(HUB_INDEX, "rb") as f:
                self.wfile.write(f.read())
            return

        # 路由到对应项目
        for prefix, root in PROJECTS.items():
            if path.startswith(prefix):
                rel = path[len(prefix):].lstrip("/")
                file_path = root / rel
                if file_path.is_file():
                    self.send_file(file_path)
                    return
                if file_path.is_dir():
                    file_path = file_path / "index.html"
                    if file_path.is_file():
                        self.send_file(file_path)
                        return
                # SPA 兜底
                fallback = root / (rel + ".html") if rel else root / "index.html"
                if fallback.is_file():
                    self.send_file(fallback)
                    return
                fallback = root / "index.html"
                if fallback.is_file():
                    self.send_file(fallback)
                    return
                self.send_error(404, f"Not Found: {path}")
                return

        self.send_error(404, f"Not Found: {path}")

    def send_file(self, file_path):
        # VitePress 输出的 .html 默认是 text/html；其他资源按扩展名猜
        ext = file_path.suffix.lower()
        ctype = {
            ".html": "text/html; charset=utf-8",
            ".js":   "application/javascript; charset=utf-8",
            ".css":  "text/css; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".svg":  "image/svg+xml",
            ".png":  "image/png",
            ".jpg":  "image/jpeg",
            ".ico":  "image/x-icon",
        }.get(ext, "application/octet-stream")
        try:
            with open(file_path, "rb") as f:
                data = f.read()
        except OSError:
            self.send_error(404, f"Not Found: {file_path}")
            return
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, fmt, *args):
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

if __name__ == "__main__":
    print("=" * 50)
    print("  三个静态网站 - 统一访问入口")
    print("=" * 50)
    print()
    print(f"  端口: {PORT}")
    print()
    print("  访问地址:")
    print(f"    首页导航:    http://localhost:{PORT}/")
    print(f"    ES 网站:    http://localhost:{PORT}/es/")
    print(f"    MySQL 网站:  http://localhost:{PORT}/mysql/")
    print(f"    Spring Cloud: http://localhost:{PORT}/cloud/")
    print(f"    Redis:        http://localhost:{PORT}/redis/")
    print(f"    Python:       http://localhost:{PORT}/python/")
    print(f"    Kafka:        http://localhost:{PORT}/kafka/")
    print(f"    Java Web:     http://localhost:{PORT}/java/")
    print(f"    常用工具:     http://localhost:{PORT}/tools/")
    print(f"    前端 + Node:   http://localhost:{PORT}/frontend/")
    print(f"    Linux 服务器:   http://localhost:{PORT}/linux/")
    print(f"    云原生:         http://localhost:{PORT}/cloud-native/")
    print(f"    AI 工程:       http://localhost:{PORT}/ai/")
    print(f"    大数据:        http://localhost:{PORT}/bigdata/")
    print(f"    计算机网络:     http://localhost:{PORT}/network/")
    print(f"    视频处理:       http://localhost:{PORT}/video/")
    print(f"    文件系统:       http://localhost:{PORT}/filesystem/")
    print()
    print("  按 Ctrl+C 停止")
    print("=" * 50)

    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n已停止")
